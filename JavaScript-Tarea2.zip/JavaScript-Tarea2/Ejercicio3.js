function calcularAumento(nombre, salario, categoria) {
    let aumento; // Almacena el porcentaje de aumento

    // Determinar el porcentaje de aumento basado en la categoría
    switch(categoria) {
        case 'A':
            aumento = 0.15;
            break;
        case 'B':
            aumento = 0.30;
            break;
        case 'C':
            aumento = 0.10;
            break;
        case 'D':
            aumento = 0.20;
            break;
        default:
            console.log("Categoría no válida.");
            return;
    }

    // Calcular el aumento salarial
    let aumentoSalarial = salario * aumento;
    let nuevoSalario = salario + aumentoSalarial;

    // Mostrar los datos del empleado y el aumento salarial
    console.log("Nombre del Empleado: " + nombre);
    console.log("Salario Actual: $" + salario.toFixed(2));
    console.log("Categoría: " + categoria);
    console.log("Aumento Salarial: $" + aumentoSalarial.toFixed(2));
    console.log("Nuevo Salario: $" + nuevoSalario.toFixed(2));
}

// Ejemplo de uso:
let nombreEmpleado = "Noé Martinez";
let salarioEmpleado = 1000; // Salario en dólares
let categoriaEmpleado = 'B';

calcularAumento(nombreEmpleado, salarioEmpleado, categoriaEmpleado);
