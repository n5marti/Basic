const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let numeros = [];
let negativos = 0;
let positivos = 0;
let multiplosDe15 = 0;
let sumaPares = 0;

function analizarValores(index = 0) {
    if (index < 10) {
        rl.question(`Ingresa el valor ${index + 1}: `, (input) => {
            let numero = parseInt(input, 10);
            numeros.push(numero);

            // Verificar si el número es negativo o positivo
            if (numero < 0) {
                negativos++;
            } else if (numero > 0) {
                positivos++;
            }

            // Verificar si el número es múltiplo de 15
            if (numero % 15 === 0) {
                multiplosDe15++;
            }

            // Acumular si el número es par
            if (numero % 2 === 0) {
                sumaPares += numero;
            }

            // Continuar con el siguiente número
            analizarValores(index + 1);
        });
    } else {
        // Mostrar los resultados
        console.log("Cantidad de valores negativos: " + negativos);
        console.log("Cantidad de valores positivos: " + positivos);
        console.log("Cantidad de múltiplos de 15: " + multiplosDe15);
        console.log("Suma de valores pares: " + sumaPares);

        // Cerrar la interfaz de readline
        rl.close();
    }
}

// Ejecutar la función
analizarValores();
