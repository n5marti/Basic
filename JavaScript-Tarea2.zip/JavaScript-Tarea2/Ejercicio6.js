function calcularDescuentoViaje(origen, destino) {
    let descuento;

    // Determinar el descuento basado en el destino
    if (origen === "Palma") {
        switch (destino) {
            case "La costa del Sol":
                descuento = 0.05; // 5%
                break;
            case "Panchimalco":
                descuento = 0.10; // 10%
                break;
            case "Puerto el Triunfo":
                descuento = 0.15; // 15%
                break;
            default:
                descuento = 0; // Sin descuento si el destino no coincide
        }
    } else {
        descuento = 0; // Sin descuento si el origen no es Palma
    }

    return descuento * 100; // Devuelve el descuento en porcentaje
}

// Ejemplo de uso:
let origenUsuario = "Palma";
let destinoUsuario = "Panchimalco";

let descuentoAplicado = calcularDescuentoViaje(origenUsuario, destinoUsuario);
console.log(`El descuento para viajar desde ${origenUsuario} hacia ${destinoUsuario} es del ${descuentoAplicado}%.`);
