const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function convertirCelsiusAFahrenheit(celsius) {
    return (celsius * 9/5) + 32;
}

function evaluarTemperatura(fahrenheit) {
    if (fahrenheit >= 14 && fahrenheit < 32) {
        return "Temperatura baja";
    } else if (fahrenheit >= 32 && fahrenheit < 68) {
        return "Temperatura adecuada";
    } else if (fahrenheit >= 68 && fahrenheit < 96) {
        return "Temperatura alta";
    } else {
        return "Temperatura desconocida";
    }
}

rl.question('Ingresa la temperatura en Celsius: ', (input) => {
    let celsius = parseFloat(input);

    if (isNaN(celsius)) {
        console.log("Por favor, ingresa un número válido.");
    } else {
        let fahrenheit = convertirCelsiusAFahrenheit(celsius);
        console.log(`Temperatura en Fahrenheit: ${fahrenheit.toFixed(2)}`);
        
        let mensaje = evaluarTemperatura(fahrenheit);
        console.log(mensaje);
    }

    rl.close();
});