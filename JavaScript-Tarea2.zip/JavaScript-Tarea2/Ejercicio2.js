function calcularNotaFinal(nombre, carnet, examen, tareas, asistencia, investigacion) {
    // Calcular la nota final con los porcentajes correspondientes
    let notaFinal = (examen * 0.20) + (tareas * 0.40) + (asistencia * 0.10) + (investigacion * 0.30);

    // Mostrar los datos del alumno
    console.log("Nombre del Alumno: " + nombre);
    console.log("Carnet del Alumno: " + carnet);
    console.log("Nota Final: " + notaFinal.toFixed(2)); // toFixed(2) limita a 2 decimales
}

let nombreAlumno = "Noe Martinez";
let carnetAlumno = "035878967";
let notaExamen = 85;
let notaTareas = 90;
let notaAsistencia = 95;
let notaInvestigacion = 88;

calcularNotaFinal(nombreAlumno, carnetAlumno, notaExamen, notaTareas, notaAsistencia, notaInvestigacion);
