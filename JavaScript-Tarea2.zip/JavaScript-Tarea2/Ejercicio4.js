function encontrarMayor(numero1, numero2) {
    if (numero1 > numero2) {
        return numero1 + " es el número mayor.";
    } else if (numero2 > numero1) {
        return numero2 + " es el número mayor.";
    } else {
        return "Ambos números son iguales.";
    }
}

let numero1 = 15;
let numero2 = 10;

console.log(encontrarMayor(numero1, numero2));
    